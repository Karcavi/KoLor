# KoLor

Kolor App is an application created to connect students from Konrad Lorenz Fundación Universitaria.

The team aims to allow our Community offer products and services related to our academic matters, as well as look for them.


The team is formed by Karol Campo and Sebastián Méndez.


The app is being developed on Android Studio, so that users can access to it from their mobile devices, such as cellphones, tablets
and any other device Android capable.


More details will be included/revealed as the app is developed.

25/02/18
